# Air_Condition_Expert_Fuzzy_Logic
"FUZZY LOGIC BASED EXPERT SYSTEM FOR AIR CONDITION" Air conditioning systems are used to maintain a comfortable temperature and humidity level in indoor environments. 

input csv file: https://drive.google.com/file/d/12efwMZJGHSx5E69M3PZze2kXxBhp3ZjH/view?usp=sharing